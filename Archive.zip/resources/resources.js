const de = require('./language/de');
const us = require('./language/en');

module.exports = {
'de-DE': de,
'en-US': us
};
