const resource = {
    'translation': {
        'JOKES': [
            'Chuck Norris was bitten by a cobra and after five days of excruciating pain... the cobra died.',
            'Chuck Norris can kill two stones with one bird.'
        ],
        'SKILL_NAME' : 'Witzeerzähler',
        'HELP_MESSAGE' : 'You can say tell me a joke in swabian, or, you can say exit... What can I help you with?',
        'HELP_REPROMPT' : 'What can I help you with?',
        'STOP_MESSAGE' : 'Goodbye!'
    }
};

module.exports = resource;
