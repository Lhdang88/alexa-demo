const resource = {
    'translation': {
        'JOKES': [
          'Warum sollten zwei Arschbacken nie heiraten? Weil sie bei jedem Scheiß auseinander gehen.',
          'Wie trinkt Chuck Norris seinen Kaffee? Antwort: Schwarz ohne Wasser!',
          'Chuck Norris kann mit Durchfall furzen.',
          'Chuck Norris wurde neulich geblitzt. beim Einparken.',
          'Chuck Norris kann bei Yahoo googeln.',
          'Chuck Norris hat keine Wimpern. Das sind Augenbärte.',
          'Chuck Norris ist so schnell, dass er um die Erde rennen und sich selbst in den Rücken treten könnte. Aber er würde diesen Angriff kommen sehen.',
          'Chuck Norris zündet ein Feuer an, indem er zwei Eiswürfel aneinander reibt.',
          'Einmal warf Chuck Norris eine Handgranate und tötete damit 100 Leute. Zwei Sekunden später explodierte sie.',
          'Chuck Norris hat keine Herzattacken. Kein Herz wäre so verrückt Chuck zu attackieren.',
          'Chuck Norris ist so gut bestückt. Es reicht sogar für eine Fernbeziehung.',
          'Chuck Norris und Superman haben eine Wette gemacht und der Verlierer sollte seine Unterhose über dem Anzug tragen.',
          'Alle Kinder, die damals beim Verstecken spielen die Besten waren, arbeiten heute im Baumarkt.'
        ],
        'SKILL_NAME' : 'Witzeerzähler',
        'HELP_MESSAGE' : 'Du kannst sagen, „Erzähle mir einen Witz auf Schwäbisch“, oder du kannst „Beenden“ sagen... Wie kann ich dir helfen?',
        'HELP_REPROMPT' : 'Wie kann ich dir helfen?',
        'STOP_MESSAGE' : 'Auf Wiedersehen!'
    }
  };

module.exports = resource;
